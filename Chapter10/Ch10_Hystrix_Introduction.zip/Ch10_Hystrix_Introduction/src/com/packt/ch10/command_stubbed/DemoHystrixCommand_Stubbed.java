package com.packt.ch10.command_stubbed;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;

public class DemoHystrixCommand_Stubbed extends HystrixCommand<Employee> {

	private long employeeId;

	public DemoHystrixCommand_Stubbed(long employeeId) {
		super(HystrixCommandGroupKey.Factory.asKey("packtGroup"));
		this.employeeId = employeeId;
	}

	@Override
	protected Employee run() throws Exception {
		// TODO Auto-generated method stub
		throw new RuntimeException("You got an exception");
		
	}
	
	@Override
	protected Employee getFallback() {
		// TODO Auto-generated method stub
		 return new Employee("dummy_name", employeeId, "dummy address", "1234567", "dummy last name");
	}

}
