package com.packt.ch10.commands_fallback;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;

public class DemoHystrixCommand_Fallback extends HystrixCommand<String>{
	private String user;

	public DemoHystrixCommand_Fallback(String user) {
			// TODO Auto-generated constructor stub
			super(HystrixCommandGroupKey.Factory.asKey("packtGroup"));
			this.user=user;
	}

	@Override
	protected String run() throws Exception {
		// TODO Auto-generated method stub
        throw new RuntimeException("Exception occured");
	}

	@Override
	protected String getFallback() {
		// TODO Auto-generated method stub
		return "Sorry!!! We failed";
	}
}
