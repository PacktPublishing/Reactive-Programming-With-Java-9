package com.packt.ch10.commands_fallback;

import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixObservableCommand;

import rx.Observable;

public class DemoHystrixObservableCommand_Fallback extends HystrixObservableCommand<String> {
	private String user;

	public DemoHystrixObservableCommand_Fallback(String user) {
		// TODO Auto-generated constructor stub
		super(HystrixCommandGroupKey.Factory.asKey("packtGroup"));
		this.user = user;
	}

	@Override
	protected Observable<String> construct() {
		// TODO Auto-generated method stub
		throw new RuntimeException("Got an exception");
	}

	@Override
	protected Observable<String> resumeWithFallback() {
		// TODO Auto-generated method stub
		return Observable.just("resumeFallback");
	}

}
