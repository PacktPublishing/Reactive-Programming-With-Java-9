package com.packt.ch10.command_dual_mode;

import com.netflix.config.DynamicBooleanProperty;
import com.netflix.config.DynamicPropertyFactory;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandKey;
import com.netflix.hystrix.HystrixCommandProperties;
import com.netflix.hystrix.HystrixCommandProperties.ExecutionIsolationStrategy;
import com.netflix.hystrix.HystrixThreadPoolKey;

public class DemoCommandFacade extends HystrixCommand<String> {
	private String user;
	private final static DynamicBooleanProperty property = DynamicPropertyFactory.getInstance()
			.getBooleanProperty("property.usePrimaryCommand", true);

	public DemoCommandFacade(String user) {
		// TODO Auto-generated constructor stub
		super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("Hystrix_Facade"))
				.andCommandKey(HystrixCommandKey.Factory.asKey("packtGroup_Facade")).andCommandPropertiesDefaults(
						// use semaphore-isolation
						HystrixCommandProperties.Setter()
								.withExecutionIsolationStrategy(ExecutionIsolationStrategy.SEMAPHORE)));
		this.user = user;
	}

	@Override
	protected String run() throws Exception {
		// TODO Auto-generated method stub
		if (property.get())
			return new DemoPrimaryHystrix(user).queue().get();
		else
			return new DemoSecondaryHystrix(user).queue().get();
	}

	@Override
	protected String getFallback() {
		// TODO Auto-generated method stub
		return "sorry failed:-";
	}



	private class DemoPrimaryHystrix extends HystrixCommand<String> {
		private String user;

		public DemoPrimaryHystrix(String user) {
			super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("Hystrix_Facade"))
					.andCommandKey(HystrixCommandKey.Factory.asKey("Command1"))
					.andThreadPoolKey(HystrixThreadPoolKey.Factory.asKey("Command1"))
					.andCommandPropertiesDefaults(
							// we default to a 600ms timeout for primary
							HystrixCommandProperties.Setter().withExecutionTimeoutInMilliseconds(600)));
			this.user = user;
		}

		@Override
		protected String run() {
			// give a service call here and return the obtained value
			return "I am from DemoPrimaryHystrix:-" + user;
		}
	}

	private class DemoSecondaryHystrix extends HystrixCommand<String> {
		private String user;

		public DemoSecondaryHystrix(String user) {
			super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("Hystrix_Facade"))
					.andCommandKey(HystrixCommandKey.Factory.asKey("Command2"))
					.andThreadPoolKey(HystrixThreadPoolKey.Factory.asKey("Command2"))
					.andCommandPropertiesDefaults(
							HystrixCommandProperties.Setter().withExecutionTimeoutInMilliseconds(600)));
			this.user = user;
		}

		@Override
		protected String run() {
			// give a service call here and return the obtained value
			return "I am from DemoSecondaryHystrix:-" + user;
		}

	}
}
