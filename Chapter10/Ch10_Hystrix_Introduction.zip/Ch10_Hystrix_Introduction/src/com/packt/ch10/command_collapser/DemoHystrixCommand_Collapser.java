package com.packt.ch10.command_collapser;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.netflix.hystrix.HystrixCollapser;
import com.netflix.hystrix.HystrixCollapserKey;
import com.netflix.hystrix.HystrixCollapserProperties;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandKey;
import com.netflix.hystrix.HystrixCollapser.CollapsedRequest;
import com.netflix.hystrix.HystrixCommand.Setter;

public class DemoHystrixCommand_Collapser extends HystrixCollapser<List<String>, String, String> {

	private String userName;

	public DemoHystrixCommand_Collapser(String userName) {
		// TODO Auto-generated constructor stub
		super(Setter.
                withCollapserKey(HystrixCollapserKey.Factory.asKey("demoHystrixCommand_Collapser"))
                .andCollapserPropertiesDefaults(HystrixCollapserProperties.Setter().withTimerDelayInMilliseconds(100)));
		this.userName = userName;
	}

	@Override
	protected HystrixCommand<List<String>> createCommand(
			Collection<CollapsedRequest<String, String>> collapsedRequests) {
		// TODO Auto-generated method stub
		System.out.println("invoked createcommand");
		return new BatchHystrixCommand(collapsedRequests);
	}

	@Override
	public String getRequestArgument() {
		// TODO Auto-generated method stub
		System.out.println("key gathered for:-"+userName);
		return userName;
	}

	@Override
	protected void mapResponseToRequests(List<String> batch_response,
			Collection<CollapsedRequest<String, String>> collapsedRequests) {
		// TODO Auto-generated method stub
		System.out.println("mapping response with size:-" + collapsedRequests.size());
		int i = 0;
		for(CollapsedRequest<String, String>request:collapsedRequests)
			request.setResponse(batch_response.get(i++));
	}

}
