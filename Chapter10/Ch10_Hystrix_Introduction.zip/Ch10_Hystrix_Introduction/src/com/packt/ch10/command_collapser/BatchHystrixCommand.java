package com.packt.ch10.command_collapser;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.netflix.hystrix.HystrixCollapser.CollapsedRequest;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandKey;

public class BatchHystrixCommand extends HystrixCommand<List<String>> {

	Collection<CollapsedRequest<String, String>> collapsedRequests;

	public BatchHystrixCommand(Collection<CollapsedRequest<String, String>> collapsedRequests ) {
		// TODO Auto-generated constructor stub
		super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("ExampleGroup"))
				.andCommandKey(HystrixCommandKey.Factory.asKey("GetValueForKey")));
		this.collapsedRequests = collapsedRequests;
	}

	@Override
	protected List<String> run() throws Exception {
		// TODO Auto-generated method stub
        int i=0;
		List<String> users = new ArrayList<>();
		for (CollapsedRequest<String, String> request : collapsedRequests) {
//			System.out.println("finding:-"+request.getArgument());
			users.add("user "+i+++request.getArgument());
		}
		return users;
	}
	


}
