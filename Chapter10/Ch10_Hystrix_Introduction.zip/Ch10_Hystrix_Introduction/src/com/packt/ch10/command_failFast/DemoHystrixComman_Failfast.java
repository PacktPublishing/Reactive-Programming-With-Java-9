package com.packt.ch10.command_failFast;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;

public class DemoHystrixComman_Failfast extends HystrixCommand<String> {

	private String user;

	public DemoHystrixComman_Failfast(String user) {
		// TODO Auto-generated constructor stub
		super(HystrixCommandGroupKey.Factory.asKey("packtGroup"));
		this.user = user;
	}

	@Override
	protected String run() throws Exception {
		// TODO Auto-generated method stub
		if (user.length() > 10)
			throw new RuntimeException("Length greater than 10");
		return "Welcome to Hystrix, " + user;
	}

}
