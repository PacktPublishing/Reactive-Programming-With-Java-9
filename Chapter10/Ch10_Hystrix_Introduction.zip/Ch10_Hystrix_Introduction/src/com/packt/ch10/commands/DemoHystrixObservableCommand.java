package com.packt.ch10.commands;

import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixObservableCommand;

import rx.Observable;

public class DemoHystrixObservableCommand extends HystrixObservableCommand<String> {
     private String user;
	
	public DemoHystrixObservableCommand(String user) {
			// TODO Auto-generated constructor stub
			super(HystrixCommandGroupKey.Factory.asKey("packtGroup"));
			this.user=user;
	}

	@Override
	protected Observable<String> construct() {
		// TODO Auto-generated method stub
		return Observable.just("Welcome to Hystrix, "+user);
	}

	@Override
	protected Observable<String> resumeWithFallback() {
		// TODO Auto-generated method stub
		return Observable.just("Fallback");
	}

}
