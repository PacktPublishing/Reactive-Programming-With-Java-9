package com.packt.ch10.commands;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;

public class DemoHystrixCommand extends HystrixCommand<String>{
	private String user;
	
	public DemoHystrixCommand(String user) {
			// TODO Auto-generated constructor stub
			super(HystrixCommandGroupKey.Factory.asKey("packtGroup"));
			this.user=user;
	}

	@Override
	protected String run() throws Exception {
		// TODO Auto-generated method stub
		return "Welcome to Hystrix, "+ user;
	}
}
