package com.packt.ch10.command_cache;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;

public class DemoHystricCommand_cache extends HystrixCommand<String> {

    private final int value;

    public DemoHystricCommand_cache(int value) {
        super(HystrixCommandGroupKey.Factory.asKey("packt_pub"));
        this.value = value;
    }

    @Override
    protected String run() {
        return "welcome:-"+ value;
    }

    @Override
    protected String getCacheKey() {
        return String.valueOf(value);
    }
}