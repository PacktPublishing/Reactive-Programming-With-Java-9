package com.packt.ch10.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.junit.After;
import org.junit.Test;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixObservableCommand;
import com.packt.ch10.commands.DemoHystrixObservableCommand;
import com.packt.ch10.commands_fallback.DemoHystrixCommand_Fallback;
import com.packt.ch10.commands_fallback.DemoHystrixObservableCommand_Fallback;

import rx.Observable;
import rx.observers.TestSubscriber;

public class TestDemoHystrixCommandObservable_Fallback {

	@After
	public void tearDown() throws Exception {
	}

	@Test()
	public void test_observe() {
		HystrixObservableCommand<String> command = new DemoHystrixObservableCommand_Fallback("Packt Pub");
		TestSubscriber<String > testSubscriber=new TestSubscriber<>();
		command.observe().subscribe(testSubscriber);

		List<String>list=new ArrayList<>();
		list.add("resumeFallback");
		testSubscriber.assertReceivedOnNext(list);
	}

	@Test()
	public void test_toObservale() {
		HystrixObservableCommand<String> command = new DemoHystrixObservableCommand_Fallback("Packt Pub");
		TestSubscriber<String> testSubscriber = new TestSubscriber<>();
		command.toObservable().subscribe(testSubscriber);

		List<String> list = new ArrayList<>();
		list.add("resumeFallback");
		testSubscriber.assertReceivedOnNext(list);
	}
}
