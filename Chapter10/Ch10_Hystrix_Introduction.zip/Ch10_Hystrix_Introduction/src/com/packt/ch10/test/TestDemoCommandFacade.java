package com.packt.ch10.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;
import com.packt.ch10.command_dual_mode.DemoCommandFacade;
import com.netflix.config.ConfigurationManager;

public class TestDemoCommandFacade {

	@Test
    public void testPrimaryCommand() {
        HystrixRequestContext context = HystrixRequestContext.initializeContext();
        try {
            ConfigurationManager.getConfigInstance().setProperty("property.usePrimaryCommand", true);
            assertEquals("I am from DemoPrimaryHystrix:-packt", new DemoCommandFacade("packt").execute());
        } finally {
            context.shutdown();
            ConfigurationManager.getConfigInstance().clear();
        }
    }
	
	@Test
    public void testSecondaryCommand() {
        HystrixRequestContext context = HystrixRequestContext.initializeContext();
        try {
            ConfigurationManager.getConfigInstance().setProperty("property.usePrimaryCommand", false);
            assertEquals("I am from DemoSecondaryHystrix:-packt", new DemoCommandFacade("packt").execute());
        } finally {
            context.shutdown();
            ConfigurationManager.getConfigInstance().clear();
        }
    }
}
