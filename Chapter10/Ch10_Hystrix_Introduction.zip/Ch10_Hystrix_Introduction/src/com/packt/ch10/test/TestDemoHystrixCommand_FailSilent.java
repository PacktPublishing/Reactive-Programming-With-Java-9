package com.packt.ch10.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.concurrent.ExecutionException;

import org.junit.Test;

import com.netflix.hystrix.HystrixCommand;
import com.packt.ch10.command_failFast.DemoHystrixComman_Failfast;
import com.packt.ch10.command_failSilent.DemoHystrixCommand_FailSilent;

public class TestDemoHystrixCommand_FailSilent {

	@Test
	public void test_queue_exception() {
		HystrixCommand<String> command = new DemoHystrixCommand_FailSilent("Packt Publication");
		try {
			assertEquals(null, command.queue().get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			fail(e.getMessage());
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
