package com.packt.ch10.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.netflix.hystrix.HystrixEventType;
import com.netflix.hystrix.HystrixInvokableInfo;
import com.netflix.hystrix.HystrixRequestLog;
import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;
import com.packt.ch10.command_fallback_via_Network.DemoHystrixCommand_FallbackViaNetwork;

public class TestDemoCommandHystrix_FallbackViaNetwork {

	@Test
	public void test() {
		HystrixRequestContext hysContext = HystrixRequestContext.initializeContext();
		try {
			assertEquals(null, new DemoHystrixCommand_FallbackViaNetwork(1).execute());

			HystrixInvokableInfo<?> command1 = HystrixRequestLog.getCurrentRequest().getAllExecutedCommands()
					.toArray(new HystrixInvokableInfo<?>[2])[0];
			assertEquals("packt_group_Command", command1.getCommandKey().name());
			assertTrue(command1.getExecutionEvents().contains(HystrixEventType.FAILURE));

			HystrixInvokableInfo<?> command2 = HystrixRequestLog.getCurrentRequest().getAllExecutedCommands()
					.toArray(new HystrixInvokableInfo<?>[2])[1];
			assertEquals("packt_group_FallbackCommand", command2.getCommandKey().name());
			assertTrue(command2.getExecutionEvents().contains(HystrixEventType.FAILURE));
		} finally {
			hysContext.shutdown();
		}
	}
}
