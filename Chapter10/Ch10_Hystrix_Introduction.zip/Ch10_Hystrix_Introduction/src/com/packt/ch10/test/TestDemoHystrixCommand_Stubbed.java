package com.packt.ch10.test;

import org.junit.Assert;
import org.junit.Test;

import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;
import com.packt.ch10.command_stubbed.DemoHystrixCommand_Stubbed;
import com.packt.ch10.command_stubbed.Employee;

public class TestDemoHystrixCommand_Stubbed {
	
	@Test
	public void test()
	{
		DemoHystrixCommand_Stubbed demo=new DemoHystrixCommand_Stubbed(1111);
		Employee employee=demo.execute();
		
		Assert.assertEquals("dummy_name", employee.getEmployeeFName());
		Assert.assertEquals("dummy last name", employee.getEmployeeLName());
		Assert.assertEquals(1111, employee.getEmp_id());
		Assert.assertEquals("dummy address", employee.getAddress());
		Assert.assertEquals("1234567", employee.getMobileNumber());

	}

}
