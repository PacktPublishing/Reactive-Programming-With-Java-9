package com.packt.ch10.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.concurrent.ExecutionException;

import org.junit.Test;

import com.netflix.hystrix.HystrixCommand;
import com.packt.ch10.commands_fallback.DemoHystrixCommand_Fallback;

public class TestDemoHystrixCommand_Fallback {
	@Test()
	public void test_command() {
		HystrixCommand<String>command=new DemoHystrixCommand_Fallback("Packt Pub");
		assertEquals("Sorry!!! We failed",command.execute());
	}
	
	@Test
	public void test_queue() {
		HystrixCommand<String>command=new DemoHystrixCommand_Fallback("Packt Pub");
		try {
			assertEquals("Sorry!!! We failed",command.queue().get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			fail(e.getMessage());
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			fail(e.getMessage());
		}
	}

}
