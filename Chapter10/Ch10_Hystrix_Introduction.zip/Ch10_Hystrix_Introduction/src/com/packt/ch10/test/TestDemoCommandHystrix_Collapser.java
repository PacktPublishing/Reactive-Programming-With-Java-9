package com.packt.ch10.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;

import com.netflix.hystrix.HystrixCollapser;
import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixEventType;
import com.netflix.hystrix.HystrixRequestCache;
import com.netflix.hystrix.HystrixRequestLog;
import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;
import com.packt.ch10.command_collapser.DemoHystrixCommand_Collapser;

import junit.framework.Assert;

public class TestDemoCommandHystrix_Collapser {

	@Test
	public void test()
	{
		HystrixRequestContext ctx=HystrixRequestContext.initializeContext();
		
		
		Future<String> user1=new DemoHystrixCommand_Collapser("packt").queue();
		Future<String> user2=new DemoHystrixCommand_Collapser("publication").queue();
		Future<String> user3=new DemoHystrixCommand_Collapser("reactive").queue();
		Future<String> user4=new DemoHystrixCommand_Collapser("programming").queue();
//		
		
		
		try {
			assertEquals("user 1 packt", user1.get());
			assertEquals("user 2 publication", user2.get());
			assertEquals("user 3 reactive", user3.get());
			assertEquals("user 4 programming", user4.get());
			
			assertEquals(1,HystrixRequestLog.getCurrentRequest().getExecutedCommands().size());
			HystrixCommand<?> command = HystrixRequestLog.getCurrentRequest().getExecutedCommands().toArray(new HystrixCommand<?>[1])[0];

			assertEquals("GetValueForKey", command.getCommandKey().name());
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			ctx.shutdown();
		}
		
	}
	
		
}
