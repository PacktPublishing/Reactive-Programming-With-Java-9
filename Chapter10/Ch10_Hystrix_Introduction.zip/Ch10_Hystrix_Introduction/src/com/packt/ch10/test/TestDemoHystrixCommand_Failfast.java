package com.packt.ch10.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.concurrent.ExecutionException;

import org.junit.Test;

import com.netflix.hystrix.HystrixCommand;
import com.packt.ch10.command_failFast.DemoHystrixComman_Failfast;
import com.packt.ch10.commands.DemoHystrixCommand;

public class TestDemoHystrixCommand_Failfast {
	
	@Test()
	public void test_command() {
		HystrixCommand<String>command=new DemoHystrixComman_Failfast("Packt Pub");
		assertEquals("Welcome to Hystrix, Packt Pub",command.execute());
	}
	
	@Test
	public void test_queue_exception() {
		HystrixCommand<String>command=new DemoHystrixComman_Failfast("Packt Publication");
		try {
			command.queue();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			assertEquals("Length greater than 10", e.getMessage());
		} 
	}

}
