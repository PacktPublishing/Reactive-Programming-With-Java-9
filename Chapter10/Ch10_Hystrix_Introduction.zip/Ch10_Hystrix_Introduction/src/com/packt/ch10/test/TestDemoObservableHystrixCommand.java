package com.packt.ch10.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Test;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixObservableCommand;
import com.packt.ch10.commands.DemoHystrixCommand;
import com.packt.ch10.commands.DemoHystrixObservableCommand;

import rx.Observable;
import rx.observers.TestSubscriber;

public class TestDemoObservableHystrixCommand {

	@After
	public void tearDown() throws Exception {
	}

	@Test()
	public void test_observe() {
		HystrixObservableCommand<String>command=new DemoHystrixObservableCommand("Packt Pub");
		TestSubscriber<String > testSubscriber=new TestSubscriber<>();
		command.observe().subscribe(testSubscriber);

		List<String>list=new ArrayList<>();
		list.add("Welcome to Hystrix, Packt Pub");
		testSubscriber.assertReceivedOnNext(list);
	}
	
	@Test()
	public void test_toObservale() {
		HystrixObservableCommand<String>command=new DemoHystrixObservableCommand("Packt Pub");
		TestSubscriber<String > testSubscriber=new TestSubscriber<>();
		command.toObservable().subscribe(testSubscriber);

		List<String>list=new ArrayList<>();
		list.add("Welcome to Hystrix, Packt Pub");
		testSubscriber.assertReceivedOnNext(list);
	}
	
	@Test()
	public void test_toObservale_blocking() {
		HystrixObservableCommand<String>command=new DemoHystrixObservableCommand("Packt Pub");
		Observable<String>observable=command.observe();
    	assertEquals("Welcome to Hystrix, Packt Pub", observable.toBlockingObservable().single());
	}

}
