package com.packt.ch10.test;

import static org.junit.Assert.*;

import java.util.concurrent.ExecutionException;

import org.junit.Test;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixObservableCommand;
import com.packt.ch10.commands.DemoHystrixCommand;

public class TestDemoHystrixCommand {

	@Test()
	public void test_command() {
		HystrixCommand<String>command=new DemoHystrixCommand("Packt Pub");
		assertEquals("Welcome to Hystrix, Packt Pub",command.execute());
	}
	
	@Test
	public void test_queue() {
		HystrixCommand<String>command=new DemoHystrixCommand("Packt Pub");
		try {
			assertEquals("Welcome to Hystrix, Packt Pub",command.queue().get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			fail(e.getMessage());
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			fail(e.getMessage());
		}
	}
}
