package com.packt.ch10.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Test;

import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;
import com.packt.ch10.command_cache.DemoHystricCommand_cache;


public class TestDemoCommandHystrix_cache {
	 @Test
     public void testWithCache() {
         HystrixRequestContext context = HystrixRequestContext.initializeContext();
         try {
        	 DemoHystricCommand_cache command1 = new DemoHystricCommand_cache(2);
        	 DemoHystricCommand_cache command2 = new DemoHystricCommand_cache(2);

             assertTrue(command1.execute().equals("welcome:-2"));
             assertFalse(command1.isResponseFromCache());

             assertTrue(command2.execute().equals("welcome:-2"));
             assertTrue(command2.isResponseFromCache());
         } finally {
             context.shutdown();
         }

         // start a new request context
         context = HystrixRequestContext.initializeContext();
         try {
        	 DemoHystricCommand_cache command3 = new DemoHystricCommand_cache(2);
             Assert.assertEquals("welcome:-2",command3.execute());
             assertFalse(command3.isResponseFromCache());
         } finally {
             context.shutdown();
         }
     }

}
