package com.packt.ch10.command_failSilent;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;

public class DemoHystrixCommand_FailSilent extends HystrixCommand<String> {
	private String user;

	public DemoHystrixCommand_FailSilent(String user) {
		// TODO Auto-generated constructor stub
		super(HystrixCommandGroupKey.Factory.asKey("packtGroup"));
		this.user = user;
	}

	@Override
	protected String run() throws Exception {
		// TODO Auto-generated method stub
		if (user.length() > 10)
			throw new RuntimeException("Length greater than 10");
		return "Welcome to Hystrix, " + user;
	}

	@Override
	protected String getFallback() {
		// TODO Auto-generated method stub
		return null;
	}
}
