package com.packt.ch10.command_fallback_via_Network;
import static org.junit.Assert.*;

import org.junit.Test;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandKey;
import com.netflix.hystrix.HystrixEventType;
import com.netflix.hystrix.HystrixInvokableInfo;
import com.netflix.hystrix.HystrixRequestLog;
import com.netflix.hystrix.HystrixThreadPoolKey;
import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;

public class DemoHystrixCommand_FallbackViaNetwork extends HystrixCommand<String> {
	private final int id;

	public DemoHystrixCommand_FallbackViaNetwork(int id) {
		super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("packt_group"))
				.andCommandKey(HystrixCommandKey.Factory.asKey("packt_group_Command")));
		this.id = id;
	}

	@Override
	protected String run() {
		throw new RuntimeException("Got an exception");
	}

	@Override
	protected String getFallback() {
		return new HystrixCommand_Network(id).execute();
	}

	private static class HystrixCommand_Network extends HystrixCommand<String> {
		private final int id;

		public HystrixCommand_Network(int id) {
			super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("packt_group"))
					.andCommandKey(HystrixCommandKey.Factory.asKey("packt_group_FallbackCommand"))
					// use a different threadpool for the fallback command
					// so saturating the RemoteServiceX pool won't prevent
					// fallbacks from executing
					.andThreadPoolKey(HystrixThreadPoolKey.Factory.asKey("packt_group_remote_Fallback")));
			this.id = id;
		}

		@Override
		protected String run() {
			throw new RuntimeException("the fallback also failed");
		}

		@Override
		protected String getFallback() {
			// the fallback also failed
			// so this fallback-of-a-fallback will
			// fail silently and return null
			return null;
		}
	}


}